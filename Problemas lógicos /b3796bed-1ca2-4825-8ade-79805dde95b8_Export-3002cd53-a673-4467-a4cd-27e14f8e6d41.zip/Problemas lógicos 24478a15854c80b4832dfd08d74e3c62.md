# Problemas lógicos

# 📚 Conceptos

[1-Plan de estudios generado por AI](Problemas%20lo%CC%81gicos%2024478a15854c80b4832dfd08d74e3c62/1-Plan%20de%20estudios%20generado%20por%20AI%2024478a15854c8010b7b0f66b3e16b0d3.md)

## :python: Python avanzado (opcional)

---

[2-Listas de comprensión](Problemas%20lo%CC%81gicos%2024478a15854c80b4832dfd08d74e3c62/2-Listas%20de%20comprensio%CC%81n%2024478a15854c80c3bb02db6f98e377fd.md)

[3-Lambda ](Problemas%20lo%CC%81gicos%2024478a15854c80b4832dfd08d74e3c62/3-Lambda%2024478a15854c803bbcb9efe241ab43ba.md)

---

## Problemas documentados

[Listas de compresión problemas](Problemas%20lo%CC%81gicos%2024478a15854c80b4832dfd08d74e3c62/Listas%20de%20compresio%CC%81n%20problemas%2024578a15854c809dbd74fbf72260e7e0.md)

[Map o diccionarios](Problemas%20lo%CC%81gicos%2024478a15854c80b4832dfd08d74e3c62/Map%20o%20diccionarios%2024678a15854c8076aaf6f9c1ae99b9e9.md)