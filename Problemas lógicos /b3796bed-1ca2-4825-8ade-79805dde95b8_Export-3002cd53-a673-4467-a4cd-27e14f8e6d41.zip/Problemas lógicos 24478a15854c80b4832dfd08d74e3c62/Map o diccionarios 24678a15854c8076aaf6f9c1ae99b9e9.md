# Map o diccionarios

Es una estructura de datos que nos permite guardar claves y valores. Es muy importante tener en cuenta que estos no se pueden repetir las claves, tienen que ser únicas. Es una estructura mutable que almacena pares clave-valor, donde las claves son únicas y permiten un acceso rápido valores asociados.

---

# Métodos útiles